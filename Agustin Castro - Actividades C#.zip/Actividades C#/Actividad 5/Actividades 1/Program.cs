﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividades_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Actividad 1
            int lado;
            string linea;
            Console.WriteLine("Ingresá el valor de un lado de un cuadrado: ");
            linea = Console.ReadLine();
            lado = int.Parse(linea);
            int perimetro = lado * 4;
            Console.WriteLine(perimetro);
        }
    }
}
