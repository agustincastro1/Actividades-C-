﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Actividad 3: Realizar un programa que lea cuatro valores numéricos e informar su suma y promedio.
            int num1, num2, num3, num4, suma, promedio;
            string linea;

            Console.Write("Ingresá el primer valor: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("Ingresá el segundo valor: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.Write("Ingresá el tercer valor: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            Console.Write("Ingresá el cuarto valor: ");
            linea = Console.ReadLine();
            num4 = int.Parse(linea);

            suma = num1 + num2 + num3 + num4;
            promedio = suma / 4;

            Console.Write("El resultado de la suma es: ");
            Console.WriteLine(suma);

            Console.Write("El promedio de la suma es: ");
            Console.WriteLine(promedio);
        }
    }
}
