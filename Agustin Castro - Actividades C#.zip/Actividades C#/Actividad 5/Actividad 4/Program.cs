﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Actividad 4
            int ValorArticulo, Cantidad, Precio;
            string linea;
            Console.Write("Ingresá el valor del articulo que lleva el cliente: ");
            linea = Console.ReadLine();
            ValorArticulo = int.Parse(linea);

            Console.Write("Ingresá la cantidad de articulos que se llevó el cliente: ");
            linea = Console.ReadLine();
            Cantidad = int.Parse(linea);
            
            Precio = ValorArticulo * Cantidad;

            Console.Write("El total a abonar es: ");
            Console.WriteLine(Precio);
        }
    }
}
