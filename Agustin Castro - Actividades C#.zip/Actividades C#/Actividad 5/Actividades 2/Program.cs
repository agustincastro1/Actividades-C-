﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividades_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Actividad 2
            int num1, num2, num3, num4, suma, producto;
            string linea;

            Console.Write("Ingresá el primer valor: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("Ingresá el segundo valor: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.Write("Ingresá el tercer valor: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            Console.Write("Ingresá el cuarto valor: ");
            linea = Console.ReadLine();
            num4 = int.Parse(linea);

            suma = num1 + num2;
            producto = num3 * num4;

            Console.Write("La suma de los dos primeros números es: ");
            Console.WriteLine(suma);

            Console.Write("El producto de los dos últimos números es: ");
            Console.Write(producto);
        }
    }
}
