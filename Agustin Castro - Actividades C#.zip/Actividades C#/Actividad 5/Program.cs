﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Actividad 5: Realizar la carga del radio de un círculo, mostrar por pantalla la circunferencia y el área del mismo.
            int Radio;
            double Pi = 3.1416, Circunferencia, Area;
            string linea;
            Console.Write("Ingresá radio de un circulo: ");
            linea = Console.ReadLine();
            Radio = int.Parse(linea);
            Circunferencia = (Radio * 2) * Pi;
            Area = (Radio * Radio) * Pi;

            Console.Write("La circunferencia del circulo es: ");
            Console.WriteLine(Circunferencia);

            Console.Write("El area del circulo es: ");
            Console.WriteLine(Area);
            Console.ReadKey();
        }
    }
}
