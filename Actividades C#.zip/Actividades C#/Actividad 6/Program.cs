﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Actividad 6: Escribir un programa que lea el peso (en kilogramos) y la altura (en metros) de una persona, y mostrar por pantalla su índice de masa corporal (IMC).
            double IMC, Altura, Peso;
            string linea;
            Console.Write("Ingresá el peso en kilos: ");
            linea = Console.ReadLine();
            Peso = Double.Parse(linea);

            Console.Write("Ingresá la Altura en metros: ");
            linea = Console.ReadLine();
            Altura = Double.Parse(linea);

            IMC = Peso / (Altura * Altura);

            Console.Write("Tiene un IMC de: ");
            Console.WriteLine(IMC);
        }
    }
}
